
adae <- merge(ae, adsl[, c("USUBJID", "TRT01A", "TRT01AN", "TRTSDT", "TRTEDT", "SAFFL")], by = "USUBJID", all.x = TRUE)
st <- adae$AESTDTC
adae$ASTDT  <- as.Date(ifelse(nchar(st) >= 10, substr(st, 1, 10), NA))
adae$AENDT  <- as.Date(ifelse(nchar(adae$AEENDTC) >= 10, substr(adae$AEENDTC, 1, 10), NA))
ym <- !is.na(st) & nchar(st) == 7
if (any(ym)) {
  first <- as.Date(paste0(st[ym], "-01"))
  same <- !is.na(adae$TRTSDT[ym]) & format(adae$TRTSDT[ym], "%Y-%m") == st[ym]
  imp <- ifelse(same, as.numeric(adae$TRTSDT[ym]), as.numeric(first))
  imp <- ifelse(!is.na(adae$AENDT[ym]) & imp > as.numeric(adae$AENDT[ym]), as.numeric(first), imp)
  adae$ASTDT[ym] <- as.Date(imp)
}
adae$ASTDTF <- ifelse(ym, "D", NA)
adae$ASTDY  <- ifelse(adae$ASTDT >= adae$TRTSDT, as.numeric(adae$ASTDT - adae$TRTSDT) + 1, as.numeric(adae$ASTDT - adae$TRTSDT))
adae$TRTEMFL <- ifelse(!is.na(adae$ASTDT) & !is.na(adae$TRTSDT) & adae$ASTDT >= adae$TRTSDT & adae$ASTDT <= adae$TRTEDT + 30, "Y", "N")
adae <- adae[order(adae$USUBJID, adae$AESEQ),
             c("STUDYID", "USUBJID", "AESEQ", "AETERM", "AEDECOD", "AEBODSYS", "AESEV", "AESER", "AEREL",
               "TRT01A", "TRT01AN", "SAFFL", "ASTDT", "ASTDTF", "AENDT", "ASTDY", "TRTEMFL")]
