
x <- qs[qs$QSTESTCD %in% c("HECSI01", "IGACHE01", "ITCH01") & qs$VISITNUM >= 2,
        c("STUDYID", "USUBJID", "QSSEQ", "QSTESTCD", "QSTEST", "VISITNUM", "VISIT", "QSDTC", "QSSTRESN", "QSLOBXFL")]
adqs <- merge(x, adsl[adsl$ITTFL == "Y", c("USUBJID", "TRT01P", "TRT01PN", "ITTFL")], by = "USUBJID")
adqs$PARAMCD <- c(HECSI01 = "HECSI", IGACHE01 = "IGACHE", ITCH01 = "ITCH")[adqs$QSTESTCD]
adqs$PARAM   <- c(HECSI01 = "HECSI total score", IGACHE01 = "IGA-CHE score", ITCH01 = "Hand eczema itch NRS")[adqs$QSTESTCD]
adqs$AVAL    <- adqs$QSSTRESN
adqs$ADT     <- as.Date(substr(adqs$QSDTC, 1, 10))
adqs$AVISITN <- unname(c("2" = 0, "3" = 2, "4" = 4, "5" = 8, "6" = 12, "7" = 16)[as.character(adqs$VISITNUM)])
adqs$AVISIT  <- ifelse(adqs$AVISITN == 0, "BASELINE", paste("WEEK", adqs$AVISITN))
adqs$ABLFL   <- ifelse(adqs$QSLOBXFL %in% "Y", "Y", NA)
bl <- adqs[adqs$ABLFL %in% "Y", ]
adqs$BASE    <- bl$AVAL[match(paste(adqs$USUBJID, adqs$PARAMCD), paste(bl$USUBJID, bl$PARAMCD))]
post <- adqs$AVISITN > 0
adqs$CHG     <- ifelse(post, adqs$AVAL - adqs$BASE, NA)
adqs$PCHG    <- ifelse(post & !is.na(adqs$BASE) & adqs$BASE != 0, 100 * adqs$CHG / adqs$BASE, NA)
adqs$CRIT1   <- c(HECSI = "HECSI-75: at least 75% improvement from baseline", IGACHE = "IGA-CHE success: 0 or 1 with at least a 2-point improvement",
                  ITCH = "Itch NRS: at least 4-point improvement (baseline 4 or more)")[adqs$PARAMCD]
r <- ifelse(adqs$PARAMCD == "HECSI", adqs$PCHG <= -75,
     ifelse(adqs$PARAMCD == "IGACHE", adqs$AVAL <= 1 & adqs$BASE - adqs$AVAL >= 2,
            ifelse(adqs$BASE >= 4, adqs$CHG <= -4, NA)))
adqs$CRIT1FL <- ifelse(!post | is.na(r), NA, ifelse(r, "Y", "N"))
adqs <- adqs[order(adqs$USUBJID, adqs$PARAMCD, adqs$AVISITN),
             c("STUDYID", "USUBJID", "TRT01P", "TRT01PN", "ITTFL", "PARAMCD", "PARAM", "AVISIT", "AVISITN", "ADT",
               "AVAL", "ABLFL", "BASE", "CHG", "PCHG", "CRIT1", "CRIT1FL", "QSSEQ")]
