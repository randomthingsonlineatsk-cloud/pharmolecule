
itt <- adsl[adsl$ITTFL == "Y", ]
w16 <- adqs[adqs$PARAMCD == "HECSI" & adqs$AVISITN == 16, ]
itt$RESP <- w16$CRIT1FL[match(itt$USUBJID, w16$USUBJID)] %in% "Y"
itt$MISS <- is.na(w16$CRIT1FL[match(itt$USUBJID, w16$USUBJID)])
groups <- c("Placebo", "Lumiravostat 10 mg", "Lumiravostat 25 mg")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
p0 <- mean(itt$RESP[itt$TRT01P == "Placebo"]); n0 <- sum(itt$TRT01P == "Placebo"); k0 <- sum(itt$RESP[itt$TRT01P == "Placebo"])
for (g in groups) {
  x <- itt[itt$TRT01P == g, ]
  add("N", g, NA, "n", nrow(x)); add("RESP", g, NA, "n", sum(x$RESP)); add("RESP", g, NA, "pct", 100 * mean(x$RESP)); add("MISS", g, NA, "n", sum(x$MISS))
  if (g != "Placebo") {
    p1 <- mean(x$RESP); n1 <- nrow(x); se <- sqrt(p1 * (1 - p1) / n1 + p0 * (1 - p0) / n0)
    add("DIFF", g, NA, "est", 100 * (p1 - p0)); add("DIFF", g, NA, "lcl", 100 * (p1 - p0 - qnorm(0.975) * se)); add("DIFF", g, NA, "ucl", 100 * (p1 - p0 + qnorm(0.975) * se))
    add("DIFF", g, NA, "p", fisher.test(matrix(c(sum(x$RESP), n1 - sum(x$RESP), k0, n0 - k0), 2))$p.value)
  }
}
ard_t4 <- do.call(rbind, rows)
