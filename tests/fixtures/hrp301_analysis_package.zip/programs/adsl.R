
trtn <- c("Placebo" = 1, "Lumiravostat 10 mg" = 2, "Lumiravostat 25 mg" = 3)
adsl <- data.frame(STUDYID = dm$STUDYID, USUBJID = dm$USUBJID, SUBJID = dm$SUBJID, SITEID = dm$SITEID,
                   AGE = dm$AGE, AGEU = dm$AGEU, SEX = dm$SEX, RACE = dm$RACE, COUNTRY = dm$COUNTRY, stringsAsFactors = FALSE)
adsl$AGEGR1  <- ifelse(adsl$AGE < 65, "<65", ">=65")
adsl$AGEGR1N <- ifelse(adsl$AGE < 65, 1, 2)
adsl$TRT01P  <- dm$ARM
adsl$TRT01PN <- unname(trtn[dm$ARM])
adsl$TRT01A  <- dm$ACTARM
adsl$TRT01AN <- unname(trtn[dm$ACTARM])
adsl$TRTSDT  <- as.Date(substr(dm$RFXSTDTC, 1, 10))
adsl$TRTEDT  <- as.Date(substr(dm$RFXENDTC, 1, 10))
adsl$TRTDURD <- as.numeric(adsl$TRTEDT - adsl$TRTSDT) + 1
adsl$RANDFL  <- ifelse(!is.na(dm$ARMCD), "Y", "N")
adsl$ITTFL   <- adsl$RANDFL
adsl$SAFFL   <- ifelse(adsl$RANDFL == "Y" & !is.na(adsl$TRTSDT), "Y", "N")
bl <- qs[qs$QSLOBXFL %in% "Y", ]
b <- function(cd) bl$QSSTRESN[bl$QSTESTCD == cd][match(adsl$USUBJID, bl$USUBJID[bl$QSTESTCD == cd])]
adsl$HECSIBL <- b("HECSI01")
adsl$IGABL   <- b("IGACHE01")
adsl$ITCHBL  <- b("ITCH01")
