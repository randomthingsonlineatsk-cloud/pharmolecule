
d <- adqs[adqs$PARAMCD == "HECSI" & adqs$AVISITN > 0 & !is.na(adqs$PCHG), ]
f1 <- aggregate(PCHG ~ TRT01P + AVISITN, data = d, FUN = function(x) c(MEAN = mean(x), SE = sd(x) / sqrt(length(x))))
f1 <- data.frame(TRT01P = f1$TRT01P, AVISITN = f1$AVISITN, MEAN = f1$PCHG[, "MEAN"], SE = f1$PCHG[, "SE"], stringsAsFactors = FALSE)
f1 <- f1[order(f1$TRT01P, f1$AVISITN), ]
cols <- c("Placebo" = "grey40", "Lumiravostat 10 mg" = "steelblue", "Lumiravostat 25 mg" = "darkorange")
plot(NA, xlim = c(0, 16), ylim = range(c(0, f1$MEAN - f1$SE, f1$MEAN + f1$SE)), xlab = "Week", ylab = "Mean % change from baseline in HECSI", main = "HECSI: mean percent change from baseline (SE)")
abline(h = 0, lty = 3)
for (g in names(cols)) { x <- f1[f1$TRT01P == g, ]; lines(c(0, x$AVISITN), c(0, x$MEAN), type = "b", pch = 19, col = cols[g]); arrows(x$AVISITN, x$MEAN - x$SE, x$AVISITN, x$MEAN + x$SE, angle = 90, code = 3, length = 0.04, col = cols[g]) }
legend("bottomleft", legend = names(cols), col = cols, lty = 1, pch = 19, bty = "n")
