
l1 <- adae[adae$AESER == "Y", c("USUBJID", "TRT01A", "AEDECOD", "AEBODSYS", "ASTDT", "AENDT", "ASTDY", "AESEV", "AEREL", "TRTEMFL")]
l1 <- l1[order(l1$TRT01A, l1$USUBJID, l1$ASTDT), ]
