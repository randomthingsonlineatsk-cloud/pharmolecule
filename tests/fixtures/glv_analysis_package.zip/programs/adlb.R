
hb <- lb[lb$LBTESTCD == "HBA1C", c("STUDYID", "USUBJID", "LBSEQ", "VISITNUM", "VISIT", "LBDTC", "LBSTRESN", "LBLOBXFL")]
adlb <- merge(hb, adsl[adsl$ITTFL == "Y", c("USUBJID", "TRT01P", "TRT01PN", "TRTSDT", "ITTFL")], by = "USUBJID")
adlb$PARAMCD <- "HBA1C"
adlb$PARAM   <- "Hemoglobin A1C (%)"
adlb$AVAL    <- adlb$LBSTRESN
adlb$ADT     <- as.Date(substr(adlb$LBDTC, 1, 10))
adlb$AVISITN <- c("1" = 0, "4" = 4, "6" = 12, "9" = 26)[as.character(adlb$VISITNUM)]
adlb$AVISIT  <- ifelse(adlb$AVISITN == 0, "BASELINE", paste("WEEK", adlb$AVISITN))
adlb$ABLFL   <- ifelse(adlb$LBLOBXFL %in% "Y", "Y", NA)
bl <- adlb[adlb$ABLFL %in% "Y", c("USUBJID", "AVAL")]
adlb$BASE    <- bl$AVAL[match(adlb$USUBJID, bl$USUBJID)]
adlb$CHG     <- ifelse(adlb$AVISITN > 0, adlb$AVAL - adlb$BASE, NA)
adlb$ANL01FL <- "Y"
adlb <- adlb[order(adlb$USUBJID, adlb$AVISITN),
             c("STUDYID", "USUBJID", "TRT01P", "TRT01PN", "ITTFL", "PARAMCD", "PARAM", "AVISIT", "AVISITN", "ADT",
               "AVAL", "ABLFL", "BASE", "CHG", "ANL01FL", "LBSEQ")]
