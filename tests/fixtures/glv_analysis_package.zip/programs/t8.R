
pop <- adsl[adsl$SAFFL == "Y", ]
on <- adcm[adcm$ONTRTFL %in% "Y", ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg", "Total")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (g in groups) {
  N <- if (g == "Total") nrow(pop) else sum(pop$TRT01A == g)
  d <- if (g == "Total") on else on[on$TRT01A == g, ]
  add("POP", g, NA, "N", N)
  k <- length(unique(d$USUBJID)); add("ANY", g, NA, "n", k); add("ANY", g, NA, "pct", 100 * k / N)
  for (cl in sort(unique(on$CMCLAS))) {
    k <- length(unique(d$USUBJID[d$CMCLAS == cl])); add("CLASS", g, cl, "n", k); add("CLASS", g, cl, "pct", 100 * k / N)
    for (dr in sort(unique(on$CMDECOD[on$CMCLAS == cl]))) {
      k <- length(unique(d$USUBJID[d$CMCLAS == cl & d$CMDECOD == dr]))
      add("DRUG", g, paste(cl, dr, sep = " | "), "n", k); add("DRUG", g, paste(cl, dr, sep = " | "), "pct", 100 * k / N)
    }
  }
}
ard_t8 <- do.call(rbind, rows)
