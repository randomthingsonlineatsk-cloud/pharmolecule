
x <- lb[lb$LBTESTCD %in% c("ALT", "AST", "CREAT", "CHOL", "GLUC") & !(lb$LBTPT %in% "2 H POST-DOSE"),
        c("STUDYID", "USUBJID", "LBSEQ", "LBTESTCD", "LBTEST", "LBSTRESU", "VISITNUM", "LBDTC", "LBSTRESN", "LBSTNRLO", "LBSTNRHI", "LBNRIND", "LBLOBXFL")]
adlbc <- merge(x, adsl[adsl$SAFFL == "Y", c("USUBJID", "TRT01A", "TRT01AN", "SAFFL")], by = "USUBJID")
adlbc$PARAMCD <- adlbc$LBTESTCD
u <- tapply(adlbc$LBSTRESU, adlbc$LBTESTCD, function(x) x[!is.na(x)][1])
adlbc$PARAM   <- paste0(adlbc$LBTEST, " (", u[adlbc$LBTESTCD], ")")
adlbc$AVAL    <- adlbc$LBSTRESN
adlbc$ANRLO   <- adlbc$LBSTNRLO
adlbc$ANRHI   <- adlbc$LBSTNRHI
adlbc$ANRIND  <- adlbc$LBNRIND
adlbc$ADT     <- as.Date(substr(adlbc$LBDTC, 1, 10))
adlbc$AVISITN <- unname(c("1" = 0, "4" = 4, "6" = 12, "9" = 26)[as.character(adlbc$VISITNUM)])
adlbc$AVISIT  <- ifelse(adlbc$AVISITN == 0, "BASELINE", paste("WEEK", adlbc$AVISITN))
adlbc$ABLFL   <- ifelse(adlbc$LBLOBXFL %in% "Y", "Y", NA)
bl <- adlbc[adlbc$ABLFL %in% "Y", ]
k <- match(paste(adlbc$USUBJID, adlbc$PARAMCD), paste(bl$USUBJID, bl$PARAMCD))
adlbc$BASE    <- bl$AVAL[k]
adlbc$BNRIND  <- bl$ANRIND[k]
adlbc$CHG     <- ifelse(adlbc$AVISITN > 0, adlbc$AVAL - adlbc$BASE, NA)
adlbc <- adlbc[order(adlbc$USUBJID, adlbc$PARAMCD, adlbc$AVISITN),
               c("STUDYID", "USUBJID", "TRT01A", "TRT01AN", "SAFFL", "PARAMCD", "PARAM", "AVISIT", "AVISITN", "ADT",
                 "AVAL", "ANRLO", "ANRHI", "ANRIND", "ABLFL", "BASE", "BNRIND", "CHG", "LBSEQ")]
