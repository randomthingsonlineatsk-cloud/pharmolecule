
d <- advs[advs$ANL01FL %in% "Y" & advs$AVISITN %in% 26 & !is.na(advs$CHG), ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (p in sort(unique(advs$PARAMCD))) for (g in groups) {
  x <- d[d$PARAMCD == p & d$TRT01A == g, ]
  for (v in c("BASE", "AVAL", "CHG")) {
    add(v, g, p, "n", nrow(x)); add(v, g, p, "mean", mean(x[[v]])); add(v, g, p, "sd", sd(x[[v]]))
  }
}
ard_t7 <- do.call(rbind, rows)
