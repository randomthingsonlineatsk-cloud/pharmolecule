
a <- adsl[adsl$SAFFL == "Y", ]
te <- adae[adae$TRTEMFL == "Y" & !is.na(adae$ASTDT), ]
ev <- tapply(te$ASTDT, te$USUBJID, min)[a$USUBJID]
cut <- pmin(a$TRTEDT + 30, a$EOSDT, na.rm = TRUE)
t1 <- data.frame(USUBJID = a$USUBJID, PARAMCD = "TTAE", PARAM = "Time to first treatment-emergent adverse event (days)",
                 STARTDT = a$TRTSDT, ADT = as.Date(ifelse(is.na(ev), cut, ev)), CNSR = ifelse(is.na(ev), 1, 0),
                 EVNTDESC = ifelse(is.na(ev), NA, "FIRST TREATMENT-EMERGENT ADVERSE EVENT"),
                 CNSDTDSC = ifelse(is.na(ev), "END OF TEAE WINDOW OR END OF STUDY, WHICHEVER IS FIRST", NA), stringsAsFactors = FALSE)
disc <- a$EOSSTT == "DISCONTINUED"
t2 <- data.frame(USUBJID = a$USUBJID, PARAMCD = "TTDISC", PARAM = "Time to discontinuation from the study (days)",
                 STARTDT = a$TRTSDT, ADT = a$EOSDT, CNSR = ifelse(disc, 0, 1),
                 EVNTDESC = ifelse(disc, a$DCSREAS, NA), CNSDTDSC = ifelse(disc, NA, "COMPLETED THE STUDY"), stringsAsFactors = FALSE)
adtte <- rbind(t1, t2)
adtte$AVAL <- as.numeric(adtte$ADT - adtte$STARTDT) + 1
k <- match(adtte$USUBJID, a$USUBJID)
adtte$STUDYID <- a$STUDYID[k]; adtte$TRT01A <- a$TRT01A[k]; adtte$TRT01AN <- a$TRT01AN[k]; adtte$SAFFL <- "Y"
adtte <- adtte[order(adtte$PARAMCD, adtte$USUBJID),
               c("STUDYID", "USUBJID", "TRT01A", "TRT01AN", "SAFFL", "PARAMCD", "PARAM", "STARTDT", "ADT", "AVAL", "CNSR", "EVNTDESC", "CNSDTDSC")]
