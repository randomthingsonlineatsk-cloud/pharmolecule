
pop <- adsl[adsl$SAFFL == "Y", ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg", "Total")
cats <- c("1-28 days", "29-84 days", "85-182 days", ">182 days")
pop$DURCAT <- cut(pop$TRTDURD, c(0, 28, 84, 182, Inf), labels = cats)
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (g in groups) {
  d <- if (g == "Total") pop else pop[pop$TRT01A == g, ]
  N <- nrow(d); x <- d$TRTDURD
  add("POP", g, NA, "N", N)
  add("DUR", g, NA, "n", sum(!is.na(x))); add("DUR", g, NA, "mean", mean(x)); add("DUR", g, NA, "sd", sd(x))
  add("DUR", g, NA, "median", median(x)); add("DUR", g, NA, "min", min(x)); add("DUR", g, NA, "max", max(x))
  for (c in cats) { k <- sum(d$DURCAT == c); add("DURCAT", g, c, "n", k); add("DURCAT", g, c, "pct", 100 * k / N) }
  add("PYEARS", g, NA, "est", sum(x) / 365.25)
}
ard_t5 <- do.call(rbind, rows)
