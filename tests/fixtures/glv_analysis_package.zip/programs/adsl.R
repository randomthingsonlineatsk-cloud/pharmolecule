
trtn <- c("Placebo" = 1, "GLV-12 5 mg" = 2, "GLV-12 10 mg" = 3)
adsl <- data.frame(STUDYID = dm$STUDYID, USUBJID = dm$USUBJID, SUBJID = dm$SUBJID, SITEID = dm$SITEID,
                   AGE = dm$AGE, AGEU = dm$AGEU, SEX = dm$SEX, RACE = dm$RACE, ETHNIC = dm$ETHNIC, COUNTRY = dm$COUNTRY,
                   stringsAsFactors = FALSE)
adsl$AGEGR1  <- ifelse(adsl$AGE < 65, "<65", ">=65")
adsl$AGEGR1N <- ifelse(adsl$AGE < 65, 1, 2)
adsl$TRT01P  <- dm$ARM
adsl$TRT01PN <- unname(trtn[dm$ARM])
adsl$TRT01A  <- dm$ACTARM
adsl$TRT01AN <- unname(trtn[dm$ACTARM])
adsl$TRTSDT  <- as.Date(substr(dm$RFXSTDTC, 1, 10))
adsl$TRTEDT  <- as.Date(substr(dm$RFXENDTC, 1, 10))
adsl$TRTDURD <- as.numeric(adsl$TRTEDT - adsl$TRTSDT) + 1
adsl$RANDFL  <- ifelse(!is.na(dm$ARMCD), "Y", "N")
adsl$ITTFL   <- adsl$RANDFL
adsl$SAFFL   <- ifelse(adsl$RANDFL == "Y" & !is.na(adsl$TRTSDT), "Y", "N")
rnd <- ds[ds$DSDECOD == "RANDOMIZED", ]
adsl$RANDDT  <- as.Date(substr(rnd$DSSTDTC[match(adsl$USUBJID, rnd$USUBJID)], 1, 10))
disp <- ds[ds$DSCAT == "DISPOSITION EVENT", ]
i <- match(adsl$USUBJID, disp$USUBJID)
adsl$EOSSTT  <- ifelse(disp$DSDECOD[i] == "COMPLETED", "COMPLETED", "DISCONTINUED")
adsl$DCSREAS <- ifelse(disp$DSDECOD[i] == "COMPLETED", NA, disp$DSDECOD[i])
adsl$EOSDT   <- as.Date(substr(disp$DSSTDTC[i], 1, 10))
hb <- lb[lb$LBTESTCD == "HBA1C" & lb$LBLOBXFL %in% "Y", ]
adsl$HBA1CBL <- hb$LBSTRESN[match(adsl$USUBJID, hb$USUBJID)]
