
d <- adlb[adlb$AVISITN == 26 & !is.na(adlb$CHG), ]
d <- merge(d, adsl[, c("USUBJID", "AGEGR1", "SEX")], by = "USUBJID")
d$BLGR <- ifelse(d$BASE < 8.5, "<8.5%", ">=8.5%")
d$TRT <- factor(d$TRT01PN, levels = c(1, 2, 3), labels = c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg"))
subs <- list(c("Overall", "All", ""), c("Age group", "<65", "AGEGR1"), c("Age group", ">=65", "AGEGR1"),
             c("Sex", "F", "SEX"), c("Sex", "M", "SEX"), c("Baseline HbA1c", "<8.5%", "BLGR"), c("Baseline HbA1c", ">=8.5%", "BLGR"))
f3 <- do.call(rbind, lapply(subs, function(s) {
  x <- if (s[3] == "") d else d[d[[s[3]]] == s[2], ]
  fit <- lm(CHG ~ TRT + BASE, data = x); ci <- confint(fit)
  data.frame(SUBGROUP = s[1], LEVEL = s[2], N = sum(x$TRT %in% c("Placebo", "GLV-12 10 mg")),
             EST = coef(fit)[["TRTGLV-12 10 mg"]], LCL = ci["TRTGLV-12 10 mg", 1], UCL = ci["TRTGLV-12 10 mg", 2], stringsAsFactors = FALSE)
}))
y <- rev(seq_len(nrow(f3)))
par(mar = c(5, 12, 3, 2))
plot(f3$EST, y, xlim = range(c(0, f3$LCL, f3$UCL)), ylim = c(0.5, nrow(f3) + 0.5), pch = 15, yaxt = "n", ylab = "",
     xlab = "Difference from placebo in HbA1c change at Week 26 (95% CI)", main = "GLV-12 10 mg vs placebo by subgroup")
segments(f3$LCL, y, f3$UCL, y); abline(v = 0, lty = 3)
axis(2, at = y, labels = paste0(f3$SUBGROUP, ": ", f3$LEVEL, " (n=", f3$N, ")"), las = 1, cex.axis = 0.8)
