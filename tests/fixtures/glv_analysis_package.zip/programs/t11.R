
km <- function(t, e) {
  ut <- sort(unique(t)); S <- 1; v <- 0; out <- NULL
  for (u in ut) {
    n <- sum(t >= u); d <- sum(t == u & e == 1); c <- sum(t == u & e == 0)
    if (d > 0) { S <- S * (1 - d / n); v <- v + d / (n * (n - d)) }
    out <- rbind(out, data.frame(TIME = u, NRISK = n, NEVENT = d, NCENS = c, SURV = S, GW = v))
  }
  out
}

d <- adtte[adtte$PARAMCD == "TTAE", ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (g in groups) {
  x <- d[d$TRT01A == g, ]
  add("N", g, NA, "n", nrow(x)); add("EVENTS", g, NA, "n", sum(x$CNSR == 0)); add("CENSORED", g, NA, "n", sum(x$CNSR == 1))
  k <- km(x$AVAL, 1 - x$CNSR); k <- k[k$NEVENT > 0, ]
  z <- qnorm(0.975); se <- sqrt(k$GW) / abs(log(k$SURV))
  lo <- exp(-exp(log(-log(k$SURV)) + z * se)); hi <- exp(-exp(log(-log(k$SURV)) - z * se))
  first <- function(ok) if (any(ok, na.rm = TRUE)) k$TIME[which(ok)[1]] else NA
  add("MEDIAN", g, NA, "est", first(k$SURV <= 0.5)); add("MEDIAN", g, NA, "lcl", first(lo <= 0.5)); add("MEDIAN", g, NA, "ucl", first(hi <= 0.5))
}
cx <- lab_cox(d$AVAL, 1 - d$CNSR, cbind(D5 = as.numeric(d$TRT01A == "GLV-12 5 mg"), D10 = as.numeric(d$TRT01A == "GLV-12 10 mg")))
for (j in 1:2) { g <- groups[j + 1]; for (s in c("hr", "lcl", "ucl", "p")) add("HR", g, NA, s, cx[j, s]) }
ev <- d[d$CNSR == 0, ]; O <- E <- numeric(3); V <- matrix(0, 3, 3)
for (u in sort(unique(ev$AVAL))) {
  at <- d$AVAL >= u; n <- sum(at); dt <- sum(ev$AVAL == u)
  nj <- sapply(groups, function(g) sum(at & d$TRT01A == g)); dj <- sapply(groups, function(g) sum(ev$AVAL == u & ev$TRT01A == g))
  O <- O + dj; E <- E + dt * nj / n
  if (n > 1) V <- V + dt * (n - dt) / (n - 1) * (diag(nj / n) - outer(nj / n, nj / n))
}
x2 <- drop(t((O - E)[1:2]) %*% solve(V[1:2, 1:2]) %*% (O - E)[1:2])
add("LOGRANK", "Total", NA, "chisq", x2); add("LOGRANK", "Total", NA, "p", pchisq(x2, 2, lower.tail = FALSE))
ard_t11 <- do.call(rbind, rows)
