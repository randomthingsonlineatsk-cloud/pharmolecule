
r <- adsl[adsl$RANDFL == "Y", ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg", "Total")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
add("SCREENED", "Total", NA, "n", nrow(adsl))
add("SCRFAIL", "Total", NA, "n", sum(adsl$RANDFL == "N"))
reasons <- sort(unique(r$DCSREAS[r$EOSSTT == "DISCONTINUED"]))
for (g in groups) {
  d <- if (g == "Total") r else r[r$TRT01P == g, ]
  N <- nrow(d)
  add("POP", g, NA, "N", N)
  k <- sum(d$SAFFL == "Y"); add("TREATED", g, NA, "n", k); add("TREATED", g, NA, "pct", 100 * k / N)
  k <- sum(d$EOSSTT == "COMPLETED"); add("COMPLETED", g, NA, "n", k); add("COMPLETED", g, NA, "pct", 100 * k / N)
  k <- sum(d$EOSSTT == "DISCONTINUED"); add("DISC", g, NA, "n", k); add("DISC", g, NA, "pct", 100 * k / N)
  for (rs in reasons) { k <- sum(d$DCSREAS %in% rs); add("DCSREAS", g, rs, "n", k); add("DCSREAS", g, rs, "pct", 100 * k / N) }
}
ard_t4 <- do.call(rbind, rows)
