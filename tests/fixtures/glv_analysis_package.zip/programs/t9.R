
d <- adlb[adlb$AVISITN > 0 & !is.na(adlb$CHG), ]
d$TRT <- factor(d$TRT01PN, levels = c(1, 2, 3), labels = c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg"))
d$AVISIT <- factor(d$AVISITN, levels = c(4, 12, 26))
fit <- lab_mmrm(CHG ~ TRT * AVISIT + BASE * AVISIT, d, subject = "USUBJID", visit = "AVISIT")
mb <- mean(d$BASE[!duplicated(d$USUBJID)])
nd <- function(g, v) data.frame(TRT = g, AVISIT = v, BASE = mb)
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (g in levels(d$TRT)) add("N", g, NA, "n", length(unique(d$USUBJID[d$TRT == g])))
for (v in c("4", "12", "26")) {
  for (g in levels(d$TRT)) { e <- lab_estimate(fit, nd(g, v)); add("LSMEAN", g, paste("WEEK", v), "est", e[["est"]]); add("LSMEAN", g, paste("WEEK", v), "se", e[["se"]]) }
  for (g in levels(d$TRT)[-1]) {
    e <- lab_estimate(fit, nd(g, v), nd("Placebo", v))
    for (s in c("est", "lcl", "ucl", "p")) add("DIFF", g, paste("WEEK", v), s, e[[s]])
  }
}
ard_t9 <- do.call(rbind, rows)
