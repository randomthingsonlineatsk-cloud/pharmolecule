
pop <- adsl[adsl$SAFFL == "Y", ]
pop$GRP <- pop$TRT01A
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg", "Total")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (g in groups) {
  d <- if (g == "Total") pop else pop[pop$GRP == g, ]
  n <- nrow(d)
  add("POP", g, NA, "N", n)
  add("AGE", g, NA, "n", sum(!is.na(d$AGE)))
  add("AGE", g, NA, "mean", mean(d$AGE)); add("AGE", g, NA, "sd", sd(d$AGE))
  add("AGE", g, NA, "median", median(d$AGE)); add("AGE", g, NA, "min", min(d$AGE)); add("AGE", g, NA, "max", max(d$AGE))
  for (v in c("AGEGR1", "SEX", "RACE")) for (cat in sort(unique(pop[[v]]))) {
    k <- sum(d[[v]] == cat, na.rm = TRUE)
    add(v, g, cat, "n", k); add(v, g, cat, "pct", 100 * k / n)
  }
}
ard_t1 <- do.call(rbind, rows)
