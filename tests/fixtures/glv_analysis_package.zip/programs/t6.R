
d <- adlbc[adlbc$AVISITN == 26 & !is.na(adlbc$ANRIND) & !is.na(adlbc$BNRIND), ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg")
lev <- c("LOW", "NORMAL", "HIGH")
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (p in sort(unique(adlbc$PARAMCD))) for (g in groups) {
  x <- d[d$PARAMCD == p & d$TRT01A == g, ]
  N <- nrow(x); add("N", g, p, "n", N)
  for (b in lev) for (a in lev) {
    k <- sum(x$BNRIND == b & x$ANRIND == a)
    add("SHIFT", g, paste(p, b, a, sep = " | "), "n", k); add("SHIFT", g, paste(p, b, a, sep = " | "), "pct", if (N > 0) 100 * k / N else NA)
  }
}
ard_t6 <- do.call(rbind, rows)
