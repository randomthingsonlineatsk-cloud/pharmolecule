
itt <- adsl[adsl$ITTFL == "Y", c("USUBJID", "TRT01PN", "HBA1CBL")]
w26 <- adlb[adlb$AVISITN == 26 & !is.na(adlb$CHG), c("USUBJID", "CHG")]
d <- merge(itt, w26, by = "USUBJID", all.x = TRUE)
d <- d[order(d$USUBJID), ]
d$BASE <- d$HBA1CBL
d$TRT <- factor(d$TRT01PN, levels = c(1, 2, 3), labels = c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg"))
miss <- is.na(d$CHG)
ref <- lm(CHG ~ BASE, data = d[d$TRT == "Placebo" & !miss, ])
b <- coef(ref); V <- vcov(ref); s <- sigma(ref); df <- ref$df.residual
M <- 50
set.seed(20260301)
est <- matrix(NA, M, 2); var <- matrix(NA, M, 2)
for (m in 1:M) {
  sm <- s * sqrt(df / rchisq(1, df))
  bm <- b + drop(t(chol(V * (sm / s)^2)) %*% rnorm(2))
  x <- d
  x$CHG[miss] <- bm[1] + bm[2] * x$BASE[miss] + rnorm(sum(miss), 0, sm)
  co <- summary(lm(CHG ~ TRT + BASE, data = x))$coefficients
  est[m, ] <- co[c("TRTGLV-12 5 mg", "TRTGLV-12 10 mg"), "Estimate"]
  var[m, ] <- co[c("TRTGLV-12 5 mg", "TRTGLV-12 10 mg"), "Std. Error"]^2
}
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
add("N", "Total", NA, "n", nrow(d)); add("NMISS", "Total", NA, "n", sum(miss)); add("M", "Total", NA, "n", M)
for (j in 1:2) {
  g <- c("GLV-12 5 mg", "GLV-12 10 mg")[j]
  Q <- mean(est[, j]); W <- mean(var[, j]); B <- var(est[, j]); Tt <- W + (1 + 1 / M) * B
  nu <- (M - 1) * (1 + W / ((1 + 1 / M) * B))^2
  q <- qt(0.975, nu)
  add("DIFF", g, NA, "est", Q); add("DIFF", g, NA, "se", sqrt(Tt)); add("DIFF", g, NA, "lcl", Q - q * sqrt(Tt)); add("DIFF", g, NA, "ucl", Q + q * sqrt(Tt))
  add("DIFF", g, NA, "p", 2 * pt(-abs(Q / sqrt(Tt)), nu)); add("DIFF", g, NA, "df", nu)
}
ard_t10 <- do.call(rbind, rows)
