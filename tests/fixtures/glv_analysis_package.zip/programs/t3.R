
d <- adlb[adlb$AVISITN == 26 & !is.na(adlb$CHG) & adlb$ANL01FL == "Y", ]
d$TRT <- factor(d$TRT01PN, levels = c(1, 2, 3), labels = c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg"))
fit <- lm(CHG ~ TRT + BASE, data = d)
nd <- data.frame(TRT = factor(levels(d$TRT), levels = levels(d$TRT)), BASE = mean(d$BASE))
pr <- predict(fit, newdata = nd, se.fit = TRUE)
rows <- list()
add <- function(an, g, cat, st, v) rows[[length(rows) + 1]] <<- data.frame(ANALYSIS = an, GROUP = g, CATEGORY = cat, STAT = st, VALUE = v, stringsAsFactors = FALSE)
for (i in seq_along(levels(d$TRT))) {
  g <- levels(d$TRT)[i]; x <- d[d$TRT == g, ]
  add("BASE", g, NA, "n", nrow(x)); add("BASE", g, NA, "mean", mean(x$BASE)); add("BASE", g, NA, "sd", sd(x$BASE))
  add("CHG", g, NA, "n", nrow(x)); add("CHG", g, NA, "mean", mean(x$CHG)); add("CHG", g, NA, "sd", sd(x$CHG))
  add("LSMEAN", g, NA, "est", pr$fit[i]); add("LSMEAN", g, NA, "se", pr$se.fit[i])
}
ci <- confint(fit)
co <- summary(fit)$coefficients
for (g in c("GLV-12 5 mg", "GLV-12 10 mg")) {
  term <- paste0("TRT", g)
  add("DIFF", g, NA, "est", co[term, "Estimate"]); add("DIFF", g, NA, "lcl", ci[term, 1]); add("DIFF", g, NA, "ucl", ci[term, 2]); add("DIFF", g, NA, "p", co[term, "Pr(>|t|)"])
}
ard_t3 <- do.call(rbind, rows)
