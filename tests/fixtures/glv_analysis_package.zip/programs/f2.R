
km <- function(t, e) {
  ut <- sort(unique(t)); S <- 1; v <- 0; out <- NULL
  for (u in ut) {
    n <- sum(t >= u); d <- sum(t == u & e == 1); c <- sum(t == u & e == 0)
    if (d > 0) { S <- S * (1 - d / n); v <- v + d / (n * (n - d)) }
    out <- rbind(out, data.frame(TIME = u, NRISK = n, NEVENT = d, NCENS = c, SURV = S, GW = v))
  }
  out
}

d <- adtte[adtte$PARAMCD == "TTAE", ]
groups <- c("Placebo", "GLV-12 5 mg", "GLV-12 10 mg")
f2 <- do.call(rbind, lapply(groups, function(g) { x <- d[d$TRT01A == g, ]; k <- km(x$AVAL, 1 - x$CNSR); data.frame(TRT01A = g, k[, c("TIME", "NRISK", "NEVENT", "NCENS", "SURV")], stringsAsFactors = FALSE) }))
cols <- c("Placebo" = "grey40", "GLV-12 5 mg" = "steelblue", "GLV-12 10 mg" = "darkorange")
ticks <- seq(0, 196, by = 28)
par(mar = c(9, 5, 3, 1))
plot(NA, xlim = c(0, 196), ylim = c(0, 1), xaxt = "n", xlab = "", ylab = "Probability of no TEAE", main = "Time to first treatment-emergent adverse event")
axis(1, at = ticks); mtext("Days since first dose", side = 1, line = 2.2)
for (g in groups) {
  x <- f2[f2$TRT01A == g, ]
  lines(c(0, x$TIME), c(1, x$SURV), type = "s", col = cols[g], lwd = 2)
  cz <- x[x$NCENS > 0, ]; points(cz$TIME, cz$SURV, pch = 3, col = cols[g])
}
legend("topright", legend = groups, col = cols, lwd = 2, bty = "n")
mtext("Number at risk", side = 1, line = 4, adj = 0, cex = 0.8, font = 2)
for (i in seq_along(groups)) {
  x <- d[d$TRT01A == groups[i], ]
  mtext(sapply(ticks, function(t) sum(x$AVAL >= t)), side = 1, line = 4 + i, at = ticks, cex = 0.8, col = cols[groups[i]])
}
