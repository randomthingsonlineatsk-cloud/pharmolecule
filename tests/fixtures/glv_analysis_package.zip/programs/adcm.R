
x <- cm[, c("STUDYID", "USUBJID", "CMSEQ", "CMTRT", "CMDECOD", "CMCLAS", "CMINDC", "CMSTDTC", "CMENDTC", "CMENRTPT")]
adcm <- merge(x, adsl[adsl$SAFFL == "Y", c("USUBJID", "TRT01A", "TRT01AN", "TRTSDT", "TRTEDT", "SAFFL")], by = "USUBJID")
n <- nchar(adcm$CMSTDTC)
adcm$ASTDT  <- as.Date(ifelse(!is.na(n) & n >= 10, substr(adcm$CMSTDTC, 1, 10),
                       ifelse(!is.na(n) & n == 7, paste0(adcm$CMSTDTC, "-01"),
                       ifelse(!is.na(n) & n == 4, paste0(adcm$CMSTDTC, "-01-01"), NA))))
adcm$ASTDTF <- ifelse(!is.na(n) & n == 7, "D", ifelse(!is.na(n) & n == 4, "M", NA))
adcm$AENDT  <- as.Date(ifelse(!is.na(adcm$CMENDTC) & nchar(adcm$CMENDTC) >= 10, substr(adcm$CMENDTC, 1, 10), NA))
adcm$PREFL  <- ifelse(!is.na(adcm$ASTDT) & adcm$ASTDT < adcm$TRTSDT, "Y", NA)
adcm$ONTRTFL <- ifelse(!is.na(adcm$ASTDT) & adcm$ASTDT <= adcm$TRTEDT &
                       (adcm$CMENRTPT %in% "ONGOING" | is.na(adcm$AENDT) | adcm$AENDT >= adcm$TRTSDT), "Y", NA)
adcm <- adcm[order(adcm$USUBJID, adcm$CMSEQ),
             c("STUDYID", "USUBJID", "CMSEQ", "CMTRT", "CMDECOD", "CMCLAS", "CMINDC", "TRT01A", "TRT01AN", "SAFFL",
               "ASTDT", "ASTDTF", "AENDT", "CMENRTPT", "PREFL", "ONTRTFL")]
