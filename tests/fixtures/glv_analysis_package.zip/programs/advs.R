
x <- vs[vs$VSTESTCD %in% c("SYSBP", "DIABP", "PULSE", "WEIGHT"),
        c("STUDYID", "USUBJID", "VSSEQ", "VSTESTCD", "VSTEST", "VSSTRESU", "VISITNUM", "VISIT", "VSDTC", "VSSTRESN", "VSLOBXFL")]
advs <- merge(x, adsl[adsl$SAFFL == "Y", c("USUBJID", "TRT01A", "TRT01AN", "TRTSDT", "SAFFL")], by = "USUBJID")
advs$PARAMCD <- advs$VSTESTCD
u <- tapply(advs$VSSTRESU, advs$VSTESTCD, function(x) x[!is.na(x)][1])
advs$PARAM   <- paste0(advs$VSTEST, " (", u[advs$VSTESTCD], ")")
advs$AVAL    <- advs$VSSTRESN
advs$ADT     <- as.Date(substr(advs$VSDTC, 1, 10))
advs$ADY     <- ifelse(advs$ADT >= advs$TRTSDT, as.numeric(advs$ADT - advs$TRTSDT) + 1, as.numeric(advs$ADT - advs$TRTSDT))
advs$ABLFL   <- ifelse(advs$VSLOBXFL %in% "Y", "Y", NA)
lo <- c(2, 23, 44, 72, 100, 128, 163); hi <- c(22, 43, 71, 99, 127, 162, 197); wk <- c(2, 4, 8, 12, 16, 20, 26)
w <- findInterval(advs$ADY, lo)
inwin <- !is.na(advs$ADY) & w > 0 & advs$ADY <= hi[pmax(w, 1)]
advs$AVISITN <- ifelse(advs$ABLFL %in% "Y", 0, ifelse(inwin, wk[pmax(w, 1)], NA))
advs$AVISIT  <- ifelse(is.na(advs$AVISITN), NA, ifelse(advs$AVISITN == 0, "BASELINE", paste("WEEK", advs$AVISITN)))
advs$TARGET  <- ifelse(!is.na(advs$AVISITN) & advs$AVISITN > 0, 7 * advs$AVISITN + 1, NA)
o <- order(advs$USUBJID, advs$PARAMCD, advs$AVISITN, abs(advs$ADY - advs$TARGET), -advs$ADY)
s <- advs[o, ]
pick <- !duplicated(s[, c("USUBJID", "PARAMCD", "AVISITN")]) & !is.na(s$AVISITN)
advs$ANL01FL <- NA
advs$ANL01FL[o[pick]] <- "Y"
bl <- advs[advs$ABLFL %in% "Y", ]
advs$BASE    <- bl$AVAL[match(paste(advs$USUBJID, advs$PARAMCD), paste(bl$USUBJID, bl$PARAMCD))]
advs$CHG     <- ifelse(!is.na(advs$AVISITN) & advs$AVISITN > 0, advs$AVAL - advs$BASE, NA)
advs <- advs[order(advs$USUBJID, advs$PARAMCD, advs$ADT, advs$VSSEQ),
             c("STUDYID", "USUBJID", "TRT01A", "TRT01AN", "SAFFL", "PARAMCD", "PARAM", "VISIT", "ADT", "ADY",
               "AVISIT", "AVISITN", "AVAL", "ABLFL", "BASE", "CHG", "ANL01FL", "VSSEQ")]
